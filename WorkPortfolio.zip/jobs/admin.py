from django.contrib import admin
from .models import Job #Need to add to see Job on the website

# Register your models here.
admin.site.register(Job) #complement of the import job above